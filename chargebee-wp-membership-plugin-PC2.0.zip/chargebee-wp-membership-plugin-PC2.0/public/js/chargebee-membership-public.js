(function( $, wp ) {
	'use strict';

	window.Chargebee_Membership = {

		// Functions for Document Ready Event
		init: function() {
			this.register_account();
			this.user_nofication_dialog();
		},

		// Functions for Window Load Event
		initLoad: function() {
			// Slide down notification dialog box and show the message.
			$( '.cbm-user-notify-dialog' ).slideDown( "slow" );
		},


		// Auto hide and show on yes and no radio button click
		register_account: function() {
			$( '#cbm_customer_id' ).hide();
			$( '#cbm_description' ).hide();

			$( '#cbm_registration_form input[name=cbm_account]' ).change(function( ) {
				var value = $( 'input[name=cbm_account]:checked', '#cbm_registration_form' ).val();
				if ( 'yes' === value ) {
					$( '#cbm_customer_id' ).show();
					$( '#cbm_description' ).hide();
				}else {
					$( '#cbm_customer_id' ).hide();
					$( '#cbm_description' ).show();
				}
			});
		},

		//Scroll to top while error
		scrollToError: function() {
			var cbm_errors = $( '.cbm_errors' );
			if ( cbm_errors.length > 0 ) {
				var cbm_errors_offset = cbm_errors.offset();
				$( 'html,body' ).animate( {
					                          scrollTop: cbm_errors_offset.top
				                          }, 'slow' );
			}
		},

		// Close notification dialog.
		user_nofication_dialog : function () {
			$( '.cbm-close-dialog' ).on( 'click', function () {
				var _this = this;
				var params = {
					notifiy_id: $( _this ).data( 'notifiy-id' )
				};

				var delete_notification = wp.ajax.post( 'cbm_delete_notification', params );
				delete_notification.done( function ( data ) {
					var dialog = $( _this ).parent();
					dialog.slideUp( 'slow', function () {
						$( this ).remove();
					} );
				});
			} );
		}
	};

	$( document ).ready( function() {
		Chargebee_Membership.init();
	} );

	$( window ).load( function() {
		Chargebee_Membership.initLoad();
	} );

})( jQuery, window.wp );
