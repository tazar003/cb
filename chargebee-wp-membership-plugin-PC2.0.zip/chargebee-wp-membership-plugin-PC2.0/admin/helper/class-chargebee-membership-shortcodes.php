<?php
if ( ! class_exists( 'Chargebee_Membership_Product_Shortcodes' ) ) {
	/**
	 * Class to Create Shortcodes.
	 *
	 * @since    1.0.0
	 *
	 * @package    Chargebee_Membership
	 * @subpackage Chargebee_Membership/includes
	 */
	class Chargebee_Membership_Product_Shortcodes {

		/**
		 * Constructor of Chargebee_Membership_Product_Shortcodes class.
		 *
		 * @since    1.0.0
		 * @access   public
		 */
		public function __construct() {
		}

		/**
		 * To create shortcodes.
		 *
		 * @since    1.0.0
		 * @access   public
		 */
		public function run() {
			
			// Create shortcode to display subscriptions of customer.
			add_shortcode( 'cb_display_subscription', array( $this, 'render_display_subscription' ) );

			// Create shortcode to display content to only visitors.
			add_shortcode( 'cb_not_logged_in', array( $this, 'render_not_logged_in' ) );

			// Create shortcode to display content logged-in users that have an active subscription.
			add_shortcode( 'cb_paid_subscription', array( $this, 'render_paid_subscription' ) );

			// Create shortcode to display content logged-in users that do not have an active subscription.
			add_shortcode( 'cb_free_subscription', array( $this, 'render_free_subscription' ) );

			// Shortcode for restrict a portion of content other than allowed level id in this shortcode.
			add_shortcode( 'cb_content_show', array( $this, 'render_content_show_hide' ) );

			// Shortcode for restrict a portion of content for given level id in this shortcode.
			add_shortcode( 'cb_content_hide', array( $this, 'render_content_show_hide' ) );
                        
		}


		


		

		/**
		 * Function for html of registration.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @return mixed html of registration form.
		 */
		public function cbm_registration_form_fields() {
			// Output buffer for registration form.
			ob_start();

			include_once CHARGEBEE_MEMBERSHIP_PATH . 'admin/partials/chargebee-membership-registration-form.php';

			// Return data of output buffer.
			return ob_get_clean();
		}

		/**
		 * Callback function to create link to customer account page.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param int    $user_id       Current user id.
		 * @param string $customer_id   CB customer id.
		 * @param string $content       Content to link account page.
		 */
		public function generate_account_link( $user_id, $customer_id, $content ) {

			if ( ! empty( $customer_id ) ) {
				// create portal session.
				$url = 'portal_sessions';
				$parameters = array(
					'customer[id]' => $customer_id,
					'redirect_url' => esc_url( site_url() ),
				);
				$method = 'post';

				$res = Chargebee_Membership_Request::chargebee_api_request( $url, $parameters, $method );

				$account_url = '';
				// Check for empty response.
				if ( ! empty( $res ) ) {
					$res_code     = wp_remote_retrieve_response_code( $res );
					$res_data_obj = json_decode( wp_remote_retrieve_body( $res ) );
					if ( 200 === $res_code ) {
						if ( ! empty( $res_data_obj ) ) {
							$portal_session = ! empty( $res_data_obj->portal_session ) ? $res_data_obj->portal_session : '';
							$account_url = ! empty( $portal_session->access_url ) ? $portal_session->access_url : '';
						}
					}
				}

				if ( ! empty( $account_url ) ) {
					?>
					<a href="<?php echo esc_url( $account_url ); ?>" target="_blank"><?php echo esc_html( $content ); ?></a>
					<?php
				} else {
					echo '<a href="#" >' . esc_html( $content ) . '</a>';
				}
			}
		}
	

		
		/**
		 * Callback function to display subscriptions of the customer.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param array  $atts attributes of shortcode.
		 * @param string $content shortcode contents.
		 *
		 * @return mix|string  subscription table of customer.
		 */
		public function render_display_subscription( $atts = array(), $content = '' ) {
			ob_start();
			?>
			<br/>
			<?php
			// Check if user is logged in.
			if ( is_user_logged_in() ) {
				$user_id     = get_current_user_id();
				$customer_id = get_user_meta( $user_id, 'chargebee_user_id', true );

				if ( ! empty( $customer_id ) ) {
					// Get subscriptions from usermeta.
					$subscriptions = get_user_meta( $user_id, 'chargebee_user_subscriptions', true );

					if ( ! empty( $subscriptions ) ) {
						include_once CHARGEBEE_MEMBERSHIP_PATH . 'admin/partials/chargebee-membership-subscriptions-display.php';

						// Display account page link.
						self::generate_account_link( $user_id, $customer_id, 'Your Account' );
					} else {
						esc_html_e( 'You don\'t have any subscriptions to display.', 'chargebee-membership' );
					}
				} else {
					esc_html_e( 'Either you are not a member or your Customer Id is not added.', 'chargebee-membership' );
				}
			} else {
				$options = get_option( 'cbm_pages' );

				if ( ! empty( $options['cbm_login_page'] ) ) {
					$url = get_permalink( $options['cbm_login_page'] );
				}

				$valid_tags = array(
					'a' => array(
						'href' => array(),
					),
				);

				printf(
					wp_kses(
						__( 'Please <a href="%s">login</a> to see your subscriptions.', 'chargebee-membership' ),
						$valid_tags
					),
					esc_url( $url )
				);
			}// End if().

			return ob_get_clean();
		}

		/**
		 * Callback function to display content to only visitor i.e. not logged-in users.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param array  $atts attributes of shortcode.
		 * @param string $content shortcode contents.
		 *
		 * @return mix|string  content to display non logged-in user.
		 */
		public function render_not_logged_in( $atts = array(), $content = '' ) {

			$return_content = '';
			if ( ! is_user_logged_in() ) {
				// Display content if user is not logged in.
				$return_content = wp_kses_post( $content );
			}

			return $return_content;
		}

		/**
		 * Callback function to display content logged-in users that have an active subscription.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param array  $atts attributes of shortcode.
		 * @param string $content shortcode contents.
		 *
		 * @return mix|string  content to display to active user.
		 */
		public function render_paid_subscription( $atts = array(), $content = '' ) {
			global $current_user;
			$active = self::has_active_subscription();
			$return_content = '';

			// Display content to only active users.
			if ( is_user_logged_in() && $active && in_array( 'chargebee_member', $current_user->roles, true ) ) {
				$return_content = wp_kses_post( $content );
			}

			return $return_content;
		}

		/**
		 * Callback function to display content logged-in users that do not have an active subscription.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param array  $atts attributes of shortcode.
		 * @param string $content shortcode contents.
		 *
		 * @return mix|string  content to display to non-active users.
		 */
		public function render_free_subscription( $atts = array(), $content = '' ) {
			global $current_user;
			$active = self::has_active_subscription();
			$return_content = '';

			// Display content to only inactive users.
			if ( is_user_logged_in() && ! $active && in_array( 'chargebee_member', $current_user->roles, true ) ) {
				$return_content = wp_kses_post( $content );
			}

			return $return_content;
		}

		/**
		 * Function to find if current user has any active subscriptions.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @return bool  user has any active subscription or not.
		 */
		public function has_active_subscription() {
			$user       = wp_get_current_user();
			if ( ! is_object( $user ) ) {
				return false;
			}
			$user_id    = ( isset( $user->ID ) ? (int) $user->ID : 0 );
			$user_roles = ( isset( $user->roles ) ) ? $user->roles : array();

			if ( ! in_array( 'chargebee_member', $user_roles, true ) ) {
				return false;
			}
			if ( ! empty( $user_id ) ) {
				$subscriptions = get_user_meta( $user_id, 'chargebee_user_subscriptions', true );
				
				if( !empty( $subscriptions ) ) {
					$status        = array_column( $subscriptions, 'status' );
					return in_array( 'active', $status, true );
				}
				return false;
				
			} else {
				return false;
			}
		}

		/**
		 * Restrict a portion of content by level id attribute.
		 * Hide for cb_content_hide shortcode, And Show for cb_content_show shortcode.
		 *
		 * @param array  $attr {
		 *      Attributes of the cb_content_show / cb_content_hide shortcode.
		 *
		 *      @type int $level Level id for restrict content.
		 * }
		 * @param string $content Shortcode content.
		 * @param string $shortcode_name Shortcode name.
		 *
		 * @return string $content Return content within shortcode if user has access.
		 */
		public function render_content_show_hide( $attr, $content = null, $shortcode_name = '' ) {
			$args = shortcode_atts( array(
				                        'level' => 0,
			), $attr );

			// TODO : Add this to one function as it is used many places.
			$user       = wp_get_current_user();
			if ( ! is_object( $user ) ) {
				return $content;
			}
			$user_id    = ( isset( $user->ID ) ? (int) $user->ID : 0 );
			$user_roles = ( isset( $user->roles ) ) ? $user->roles : array();

			if ( ! in_array( 'chargebee_member', $user_roles, true ) ) {
				return $content;
			}

			global $post;
			$post_id = isset( $post->ID ) ? $post->ID : 0;

			if ( $this->is_restrict_content_shortcode_enable( $post_id ) ) {
				$level_id = absint( $args['level'] );
				if ( ! empty( $level_id ) ) {
					$cbm_level_product_data  = get_level_product_data();
					if ( empty( $cbm_level_product_data ) ) {
						return $content;
					}
					$cbm_restrict_level_arr    = isset( $cbm_level_product_data[ $level_id ] ) ? $cbm_level_product_data[ $level_id ] : array();
					$cbm_restrict_level_name   = isset( $cbm_restrict_level_arr['level_name'] ) ? $cbm_restrict_level_arr['level_name'] : '';
					$cbm_restrict_products_arr = isset( $cbm_restrict_level_arr['products'] ) ? $cbm_restrict_level_arr['products'] : array();
					$cbm_restrict_products     = is_array( $cbm_restrict_products_arr ) ? array_column( $cbm_restrict_products_arr, 'product_id' ) : array();
					$user_level_restrict_msg   = '';

					if ( ! empty( $cbm_restrict_level_name ) ) {
						if ( 'cb_content_show' === $shortcode_name ) {
							// TODO : This message will show from general settings.
							$user_level_restrict_msg = '<strong>This content can be accessed by ' . esc_attr( $cbm_restrict_level_name ) . ' users.</strong>';
						}
						if ( 'cb_content_hide' === $shortcode_name ) {
							// TODO : This message will show from general settings.
							$user_level_restrict_msg = '<strong>This content is restricted for ' . esc_attr( $cbm_restrict_level_name ) . ' users.</strong>';
						}
					}
					if ( ! empty( $cbm_restrict_products ) ) {
						$user_subscriptions   = get_user_meta( $user_id, 'chargebee_user_subscriptions', true );
						$user_active_products = array();
						if ( empty( $user_subscriptions ) ) {
							return $user_level_restrict_msg;
						}
						foreach ( $user_subscriptions as $user_subscription ) {
							 if ( 'active' === $user_subscription['status'] || 'in_trial' === $user_subscription['status'] || 'non_renewing' === $user_subscription['status'] ) {
								$user_active_products[] = $user_subscription['product_id'];
							}
						}
						if ( empty( $user_active_products ) ) {
							return $user_level_restrict_msg;
						}

						$user_access_can_access_level = array_intersect( $cbm_restrict_products, $user_active_products );

						/**
						 * If $user_access_can_access_level is empty user does not have level assign in the shortcode.
						 * So for cb_content_show shortcode this content is restrict for current user.
						 */
						if ( empty( $user_access_can_access_level ) && 'cb_content_show' === $shortcode_name ) {
							return $user_level_restrict_msg;
						}

						/**
						 * If $user_access_can_access_level is not empty user have level assign in the shortcode.
						 * So for cb_content_show shortcode this content is not restrict for current user.
						 */
						if ( ! empty( $user_access_can_access_level ) && 'cb_content_show' === $shortcode_name ) {
							return $content;
						}

						/**
						 * If $user_access_can_access_level is empty user does not have level assign in the shortcode.
						 * So for cb_content_hide shortcode this content is not restrict for current user.
						 */
						if ( empty( $user_access_can_access_level ) && 'cb_content_hide' === $shortcode_name ) {
							return $content;
						}

						/**
						 * If $user_access_can_access_level is not empty user have level assign in the shortcode.
						 * So for cb_content_hide shortcode this content is restrict for current user.
						 */
						if ( ! empty( $user_access_can_access_level ) && 'cb_content_hide' === $shortcode_name ) {
							return $user_level_restrict_msg;
						}
					}// End if().
				}// End if().
			}// End if().
			if ( 'cb_content_show' === $shortcode_name ) {
				return $content;
			} else {
				return '';
			}
		}

		/**
		 * Check if content restrict by shortcode is enable or not for the post.
		 *
		 * @param int $post_id Post id.
		 *
		 * @return bool
		 */
		public function is_restrict_content_shortcode_enable( $post_id ) {
			$cbm_restrict_option = get_post_meta( $post_id, 'cbm_restrict_option', true );
			if ( '4' === $cbm_restrict_option ) {
				return true;
			}
			return false;
		}

	}
}// End if().
