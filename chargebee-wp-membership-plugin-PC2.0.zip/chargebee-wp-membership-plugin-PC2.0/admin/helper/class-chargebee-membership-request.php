<?php
if ( ! class_exists( 'Chargebee_Membership_Request' ) ) {

	/**
	 * Class to handle chargebee requests for CURL data.
	 *
	 * @since    1.0.0
	 *
	 * @package    Chargebee_Membership
	 * @subpackage Chargebee_Membership/includes
	 */
	class Chargebee_Membership_Request {

		/**
		 * Function to send curl request and get response.
		 *
		 * @since    1.0.0
		 */
		public static function send() {

		}

		/**
		 * Function to Authenticate key and site name and Import Current Plans/Products.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param string $api   API key of chargebee.
		 * @param string $site  Site name of chargebee.
		 *
		 * @return array|WP_Error   Response object from CB API
		 */
		public static function authorize_key( $api, $site ) {
			global $CB_PLUGIN_VERSION;
			global $wp_version;
			$password = '';
			$url      = "https://{$site}.chargebee.com/api/v2/item_prices";
			$args     = array(
				'headers'   => array(
					'Authorization' => 'Basic ' . base64_encode( "$api:$password" ),
				),
				'body'      => array(
					'limit' => '100',
				),
				'sslverify' => true,
				'user-agent' => "CB/$CB_PLUGIN_VERSION/WP/$wp_version",
			);
			$response = wp_remote_get( $url, $args );

			return $response;
		}

		/**
		 * Function for Chargebee API request.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param string $url       Request url.
		 * @param array  $parameter body parameters for request.
		 * @param string $method    get or post method for request.
		 *
		 * @return mixed response of request.
		 */
		public static function chargebee_api_request( $url = '', $parameter = array(), $method = 'get' ) {
			global $CB_PLUGIN_VERSION;
                        global $wp_version;
			$api      = self::get_key();
			$site     = self::get_site();
			$password = '';
			if ( ! empty( $api ) && ! empty( $site ) ) {

				$url      = "https://{$site}.chargebee.com/api/v2/" . $url;
				$args     = array(
					'headers'   => array(
						'Authorization' => 'Basic ' . base64_encode( "$api:$password" ),
					),
					'sslverify' => false,
					'user-agent' => "CB/$CB_PLUGIN_VERSION/WP/$wp_version",
				);
				if ( ! empty( $parameter ) ) {
					$args['body'] = $parameter;
				}

				// Check method for request.
				if ( 'get' === $method ) {
					$response = wp_remote_get( $url, $args );
				} else {
					$response = wp_remote_post( $url, $args );
				}
				
				return $response;
			} else {
				return false;
			}
		}

		/**
		 * Function to get chargebee API key.
		 *
		 * @since    1.0.0
		 * @access   private
		 *
		 * @return mixed|void   Chargebee API key.
		 */
		private static function get_key() {
			return get_option( 'cbm_api_key', true );
		}

		/**
		 * Function to get chargebee Site name.
		 *
		 * @since    1.0.0
		 * @access   private
		 *
		 * @return mixed|void   Chargebee site name.
		 */
		private static function get_site() {
			return get_option( 'cbm_site_name', true );
		}
	}
}// End if().
