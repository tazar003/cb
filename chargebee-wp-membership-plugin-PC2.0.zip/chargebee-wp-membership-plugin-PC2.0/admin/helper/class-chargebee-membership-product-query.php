<?php
if ( ! class_exists( 'Chargebee_Membership_Product_Query' ) ) {

	/**
	 * Class For chargebee product queries.
	 *
	 * @since    1.0.0
	 *
	 * @package    Chargebee_Membership
	 * @subpackage Chargebee_Membership/includes
	 */
	class Chargebee_Membership_Product_Query {

		/**
		 * Function to insert all products imported from API key.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param    array $res_body product list.
		 *
		 * @return bool
		 */
		public static function insert_imported_products( $res_body ) {
			global $wpdb;
			if ( empty( $res_body ) ) {
				return false;
			}

			if ( empty( $res_body->list ) ) {
				return false;
			}

			// Insert into Products table.
			foreach ( $res_body->list as $key => $value ) {
				if ( empty( $value ) && ! is_object( $value ) ) {
					continue;
				}
				if(empty( $value->item_price )){
					return false;
				}
				$plan					=  $value->item_price;

				if(empty( $plan->currency_code)) {
					return false;
				}

				// TODO: "-1" Price means does not have value, Find out if there is a better way to handle it

				$price                	=  	isset( $plan->price ) ? $plan->price : -1;
				$tiers                	= 	! empty( $plan->tiers ) ? json_encode($plan->tiers) : '';
				$currency_code        	= 	$plan->currency_code;

				// List of zero decimal currencies supported/will be supported by Chargebee system.
				$zero_decimal_country = array(
					'KRW',
					'JPY',
					'BIF',
					'DJF',
					'PYG',
					'VND',
					'CLP',
					'GNF',
					'RWF',
					'VUV',
					'XAF',
					'XOF',
					'XPF',
					'MGA',
					'KMF',
					'ALL',
					'BYR',
				);

				// If in USD then convert cent into dollars.
				if ( ! empty( $currency_code ) &&  $price != -1  && ( ! in_array( $currency_code, $zero_decimal_country, true ) ) ) {
					$price = intval( $price ) / 100;
				}
				
				if(empty( $plan->id )){
					return false;
				}
				$sql = "SELECT product_id FROM " . CHARGEBEE_MEMBERSHIP_TABLE_PRODUCT . " where product_id='" . $plan->id . "'";
				$PRODUCT_ID = $wpdb->get_var( $sql );

				if( empty( $PRODUCT_ID ) ) {
				   $wpdb->insert(
					CHARGEBEE_MEMBERSHIP_TABLE_PRODUCT,
						array	(
							'product_id'    	=>  $plan->id,
							'product_name'   	=> ! empty( $plan->name ) ? $plan->name : (! empty( $plan->id ) ? $plan->id : ''),
							'item_id'        	=> ! empty( $plan->item_id ) ? $plan->item_id : '',
							'item_type'      	=> ! empty( $plan->item_type ) ? $plan->item_type : '',
							'description'   	=> ! empty( $plan->description ) ? $plan->description : '',
							'status'            => ! empty( $plan->status ) ? $plan->status : '',
							'external_name'     => ! empty( $plan->external_name ) ? $plan->external_name : (! empty( $plan->name ) ? $plan->name :""),
							'pricing_model'     => 	$plan->pricing_model,
							'price'				=> 	$price,
							'period'            => ! empty( $plan->period ) ? $plan->period : 1,
							'period_unit'       => ! empty( $plan->period_unit ) ? $plan->period_unit : '',
							'tiers'             =>  $tiers,
							'currency_code'     => 	$currency_code,
							'free_quantity'	    => ! empty( $plan->free_quantity ) ? $plan->free_quantity : 0,
							'trial_period'      => ! empty( $plan->trial_period ) ? $plan->trial_period : 0,
							'trial_period_unit' => ! empty( $plan->trial_period_unit ) ? $plan->trial_period_unit : '',
						),
						array( '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%d', '%s', '%s' , '%s', '%d', '%d', '%s')
					); 
				} 
				else {
				  $wpdb->replace(
					CHARGEBEE_MEMBERSHIP_TABLE_PRODUCT,
						array(
							'product_id'     	=> $PRODUCT_ID,
							'product_name'   	=> ! empty( $plan->name ) ? $plan->name : (! empty( $plan->id ) ? $plan->id : ''),
							'item_id'           => ! empty( $plan->item_id ) ? $plan->item_id : '',
							'item_type'         => ! empty( $plan->item_type ) ? $plan->item_type : '',
							'description'       => ! empty( $plan->description ) ? $plan->description : '',
							'status'            => ! empty( $plan->status ) ? $plan->status : '',
							'external_name'     => ! empty( $plan->external_name ) ? $plan->external_name : (! empty( $plan->name ) ? $plan->name :""),
							'pricing_model'     => $plan->pricing_model,
							'price'				=> $price,
							'period'            => ! empty( $plan->period ) ? $plan->period : 1 ,
							'period_unit'       => ! empty( $plan->period_unit ) ? $plan->period_unit : '',
							'tiers'             => $tiers,
							'currency_code'     => $currency_code,
							'free_quantity'	    => ! empty( $plan->free_quantity ) ? $plan->free_quantity : 0,
							'trial_period'      => ! empty( $plan->trial_period ) ? $plan->trial_period : 0,
							'trial_period_unit' => ! empty( $plan->trial_period_unit ) ? $plan->trial_period_unit : '',
						),
						array( '%d','%s', '%s', '%f', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s' )
					);
                }
			} // End foreach().
			if ( ! empty( $wpdb->last_error ) ) {
				return false;
			}
			return true;
		}

		/**
		 * Function to return Product data from product id.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param int $product_id  Product id to fetch content from custom table.
		 * @return object product data object
		 */
		public static function get_product_data( $product_id ) {
			global $wpdb;
			$str = 'SELECT * FROM ' . CHARGEBEE_MEMBERSHIP_TABLE_PRODUCT . ' WHERE product_id=%s';
			$sql = $wpdb->prepare( $str, $product_id );

			$product_obj = $wpdb->get_row( $sql );

			return $product_obj;
		}

		/**
		 * Function to update product content and Hosted Checkout URL.
		 *
		 * @since    1.0.0
		 * @access   public
		 *
		 * @param    string $product_id 			product id.
		 * @param    string $content 				content to add.
		 */
		public static function update_product_data( $product_id, $content ) {
			global $wpdb;
			$wpdb->update( CHARGEBEE_MEMBERSHIP_TABLE_PRODUCT,
				array(
					'content' => $content,
				),
				array( 'product_id' => $product_id ),
				array( '%s' ),
				array( '%s' )
			);
		}
	}
}// End if().
