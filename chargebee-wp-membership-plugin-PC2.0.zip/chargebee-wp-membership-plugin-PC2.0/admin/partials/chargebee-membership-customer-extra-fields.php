<?php
/**
 * Extra User fields for chargebee customer.
 *
 * @package    Chargebee_Membership
 * @subpackage Chargebee_Membership/admin
 */

$cust_id = get_user_meta( $user->ID, 'chargebee_user_id', true );
?>
<h3><?php esc_html_e( 'Chargebee Customer Information', 'chargebee-membership' ); ?></h3>

	<table class="form-table">

		<tr>
			<th><label for="chargebee_user_id"><?php esc_html_e( 'Customer ID:', 'chargebee-membership' ); ?></label></th>

			<td>
				<input type="text" name="chargebee_user_id" id="chargebee_user_id" value="<?php echo esc_attr( $cust_id ); ?>" class="regular-text" <?php echo empty( $cust_id ) ? null : esc_attr( 'disabled' ) ?> /><br />
				<?php if ( empty( $cust_id ) ) { ?>
					<span class="description"><?php esc_html_e( 'Please enter Chargebee Customer Id for this user.', 'chargebee-membership' ); ?></span>
				<?php } ?>
			</td>
		</tr>
		<?php
/* -- Why is not this responsive? On clicking "Create CB account" fill the customer id but the "Create CB account" button is still shown", Upon refreshing it don't come-*/
		// Display button if customer id is empty.
		if ( empty( $cust_id ) ) {
		?>
			<tr>
				<td class="cbm_separator"><?php esc_html_e( 'OR', 'chargebee-membership' ); ?></td>
			</tr>
			<tr>
				<th><label><?php esc_html_e( 'Create Chargebee User without Subscription:', 'chargebee-membership' ); ?></label></th>

				<td>
					<a class="button button-primary cbm-create-acnt" href="#" user-id="<?php echo esc_attr( $user->ID ); ?>"><?php esc_html_e( 'Create CB Account', 'chargebee-membership' ); ?></a>

					<span class="cbm-create-acnt-msg description"></span>
				</td>
			</tr>
		<?php
		}
		?>
	</table>

	<?php
	// If customer id is present then display user's subscriptions.
	if ( ! empty( $cust_id ) ) {

		// Get subscriptions from usermeta.
		$subscriptions = get_user_meta( $user->ID, 'chargebee_user_subscriptions', true );
		// If empty subscription then get subscriptions.
		if ( empty( $subscriptions ) ) {
			$url = 'subscriptions';
			$parameters = array(
				'customer_id[is]' => $cust_id,
			);

			$res = Chargebee_Membership_Request::chargebee_api_request( $url, $parameters );
			if ( ! empty( $res ) ) {

				$res_code = wp_remote_retrieve_response_code( $res );

				if ( 200 === $res_code ) {
					$list = json_Decode( wp_remote_retrieve_body( $res ) )->list;

					$new_subscriptions = array();

					// Add all subscription details into array.
					foreach ( $list as $key => $value ) {
						$sub = $value->subscription;
						$sub_items = $sub->subscription_items;
						foreach ( $sub_items as $sub_item ) {
							// INFO: Considering plans only now, addons and charges will look later 
							if( $sub_item->item_type === 'plan' ) {
								$product = Chargebee_Membership_Product_Query::get_product_data( $sub_item->item_price_id );	

								// For tiers unit price should not be shown, instead we can show tiers, Which will handle later
								$new_subscriptions[] = array(
									'subscription_id'	=> $sub->id,
									'status'			=> $sub->status,
									'currency_code'		=> $sub->currency_code,
									'product_id'		=> $sub_item->item_price_id,
									'product_name'		=> $product->product_name,
									'frequency'			=> $product->period . " " . $product->period_unit,
									'quantity'			=> $sub_item->quantity,
									'unit_price' 		=> $sub_item->unit_price,
									'amount'			=> $sub_item->amount,
								);
							}
						}
					}				

					// Add subscriptions into usermeta.
					update_user_meta( $user->ID, 'chargebee_user_subscriptions', $new_subscriptions );
					$subscriptions = $new_subscriptions;
				}
			}
		}
		include_once CHARGEBEE_MEMBERSHIP_PATH . 'admin/partials/chargebee-membership-subscriptions-display.php';
	}
	?>
<?php
